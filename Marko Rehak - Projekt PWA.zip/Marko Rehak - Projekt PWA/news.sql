-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2024 at 04:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news`
--

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id` int(11) NOT NULL,
  `ime` varchar(32) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `prezime` varchar(32) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `korisnicko_ime` varchar(32) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `lozinka` varchar(255) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `razina` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1250 COLLATE=cp1250_croatian_ci;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id`, `ime`, `prezime`, `korisnicko_ime`, `lozinka`, `razina`) VALUES
(1, 'Ime', 'Prezime', 'ivan123', '$2y$10$0viEgy7H/xpx0q7sF7YSKOaRQSbNNaUWeknvAwDmk31tsbZlycLE6', 0),
(4, 'Ime', 'Prezime', 'admin', '$2y$10$Hu270xXB4zkKuYC3YhnkoOkpCWDeT1pl9MaqUlHmitiqqqVah0bnS', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vijesti`
--

CREATE TABLE `vijesti` (
  `id` int(11) NOT NULL,
  `datum` varchar(32) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `naslov` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `sazetak` text CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `tekst` text CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `slika` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `kategorija` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `arhiva` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1250 COLLATE=cp1250_croatian_ci;

--
-- Dumping data for table `vijesti`
--

INSERT INTO `vijesti` (`id`, `datum`, `naslov`, `sazetak`, `tekst`, `slika`, `kategorija`, `arhiva`) VALUES
(1, '12.06.2024.', 'Izbori za europski parlament 2024', 'Analiza završenih izbora za EU parlament', 'Europski izbori 2024. godine odrazili su značajne političke promjene unutar Europske unije. Unatoč predviđanjima o jačanju populističke desnice, tri najveće političke grupe - EPP, S&D i Renew Europe - zadržale su svoje pozicije u Europskom parlamentu1. Hrvatska je posebno zanimljiva jer pokazuje najmanji interes za izbore za Europski parlament u usporedbi s ostalim članicama EU2.\r\n\r\nDesnica je ojačala, ali nije postigla očekivani proboj, dok su zeleni i liberali doživjeli tešku noć3. Analiza rezultata pokazuje da će se politički pejzaž EU nastaviti mijenjati, ali s jasnim naglaskom na centrističke vrijednosti. Ovo ukazuje na to da građani EU i dalje preferiraju umjerenu politiku koja se fokusira na stabilnost i integraciju.\r\n\r\n\r\nUkupno gledano, izbori su pokazali da EU ostaje predana svojim temeljnim vrijednostima, unatoč izazovima i promjenama na političkoj sceni. Budućnost EU će vjerojatno biti oblikovana umjerenim snagama koje zagovaraju kontinuitet, suradnju i zajednički napredak.', '1.jpg', 'politika', 0),
(2, '12.06.2024.', 'Sukob španjolskog premijera i argentinskog predsjednika', 'Analiza sukoba vođa dviju prijateljskih zemalja', 'Sukob između španjolskog premijera Pedra Sancheza i argentinskog predsjednika Javijera Mileija eskalirao je u diplomatsku krizu koja je kulminirala povlačenjem španjolskog ambasadora iz Buenos Airesa. Incident je započeo kada je Milei, tijekom skupa krajnje desnice u Madridu, uvrijedio Sancheza i njegovu suprugu, nazivajući je korumpiranom bez izravnog imenovanja.\r\n\r\nSanchez je zatražio javnu ispriku od Mileija, ističući da je poštovanje ključno u bilateralnim odnosima, a argentinski lider je odbio izvinjenje, tvrdeći da nema razloga za to. Španjolski ministar vanjskih poslova Jose Manuel Albares također je reagirao, naglašavajući da su Mileijeve riječi bez presedana u povijesti međunarodnih odnosa i da nadilaze političke i ideološke razlike.\r\n\r\nOvaj sukob nije izoliran incident; Milei je poznat po svojim kontroverznim komentarima o svjetskim liderima, uključujući nazivanje peruanskog predsjednika komunističkim ubojicom i opisivanje brazilskog lidera Lule da Silve kao \"divljačkog ljevičara\". Ovi događaji ukazuju na dublje napetosti u međunarodnim odnosima i potencijalne posljedice za bilateralne veze između Španjolske i Argentine.', '2.jpg', 'politika', 0),
(3, '12.06.2024.', 'Napeta utrka između Trumpa i Bidena', 'Nekoliko mjeseci prije predsjedničkih izbora još uvijek nema jasnog favorita', 'Američka predsjednička kampanja 2024. godine odvija se u sjeni globalnih događaja koji su značajno utjecali na biračko tijelo. Ekonomska zabrinutost ostaje ključna tema, s posebnim naglaskom na ratove u Gazi i Ukrajini koji bi mogli utjecati na glasače u ključnim državama1. Predviđa se vrlo tijesni izbori, gdje bi vanjska politika mogla igrati važnu ulogu na dan izbora.\r\n\r\nMladi birači, posebice, pokazuju nezadovoljstvo trenutnom administracijom, s nekima koji razmatraju podršku kandidatima treće strane ili potpuno odbijanje glasanja. Ovo ukazuje na potencijalnu promjenu u tradicionalnom biračkom ponašanju, što bi moglo imati značajne posljedice za ishod izbora.\r\n\r\nS druge strane, unutarnjopolitička pitanja, kao što su ekonomija i inflacija, i dalje dominiraju političkom scenom, s biračima koji traže rješenja za svoje ekonomske probleme. Ovo je posebno istaknuto u kontekstu rastućih cijena energenata i njihovog utjecaja na životni standard Amerikanaca.\r\n\r\nUkupno gledano, američka predsjednička kampanja 2024. godine odražava složenost suvremenih izazova i promjena u biračkim preferencijama, što bi moglo rezultirati jednim od najneizvjesnijih izbora u novijoj povijesti SAD-a.\r\n', '3.jpg', 'politika', 0),
(5, '12.06.2024.', 'Analiza reprezentacije Albanije za Euro 2024', 'Albanija na Euru 2024', 'Albanija na Euro 2024 stiže s manje pritiska, ali s jasnom namjerom da pokaže kako njihov plasman nije bio slučajan. Izbornik Sylvinho, koji je kao igrač bio poznat po svojoj taktičkoj inteligenciji, prenio je te kvalitete na nacionalnu momčad. U obrani, Berat Djimsiti i Elseid Hysaj predstavljaju kombinaciju snage i iskustva, dok je u sredini terena Kristjan Asllani postao ključan u prekidima protivničkih napada i pokretanju albanske igre.\r\n\r\nNapad je područje gdje Albanija može iznenaditi. Ernest Muçi, s svojom sposobnošću da stvara šanse iz malo prostora, i Rey Manaj, čiji instinkt za golom može biti presudan, predstavljaju glavne prijetnje za protivničke obrane. Sylvinho će se osloniti na discipliniranu igru i brze kontranapade, nadajući se da će njegova momčad biti tvrd orah za svakog protivnika.', '4.jpg', 'sport', 0),
(6, '12.06.2024.', 'Analiza reprezentacije Italije za Euro 2024', 'Italija na Euru 2024', 'Italija, s titulom prvaka Europe iz 2021. godine, dolazi na Euro 2024 s ciljem ponovnog osvajanja kontinenta. Izbornik Luciano Spalletti naslijedio je Roberto Mancinija s teškim zadatkom održavanja italijanskog duha i taktičke discipline. Gianluigi Donnarumma, već etabliran među najboljim vratarima svijeta, i dalje je stup obrane, dok su Leonardo Bonucci i Giorgio Chiellini, unatoč godinama, još uvijek ključni zbog svog iskustva i vodstva.\r\n\r\nSredina terena je mjesto gdje Italija sjaji, s Jorginhom i Nicolo Barellom koji pružaju savršenu ravnotežu između obrane i napada. Naprijed, Federico Chiesa i Ciro Immobile donose brzinu, tehniku i golgetersku oštrinu. S obzirom na njihovu sposobnost da dominiraju igrom i prilagođavaju se različitim taktičkim izazovima, Italija će biti jedan od favorita za osvajanje Euro 2024.', '5.jpg', 'sport', 0),
(7, '12.06.2024.', 'Analiza reprezentacije Španjolske za Euro 2024', 'Španjolska na Euru 2024', 'Španjolska nogometna reprezentacija, s bogatom poviješću uspjeha na europskim prvenstvima, dolazi na Euro 2024 s novom generacijom igrača spremnih za dokazivanje. Pod vodstvom izbornika Luisa de la Fuentea, La Roja se oslanja na svoju poznatu filozofiju posjeda lopte, koja je evoluirala s dodatkom direktnijeg napadačkog pristupa. Vratarska pozicija čvrsto je u rukama Unai Simona, čija su refleksna spašavanja i igra nogom postali ključni dio španjolske obrane. U srcu obrane, Aymeric Laporte i Pau Torres pružaju kombinaciju tehničke sposobnosti i fizičke prisutnosti, dok Jordi Alba i Dani Carvajal donose iskustvo na bekovskim pozicijama.\r\n\r\nSredina terena je mozak momčadi, gdje Pedrijeva kreativnost i Rodrijeva disciplina u defanzivnim zadacima omogućuju Španjolskoj kontrolu ritma igre. Napad je raznolik, s Alvaro Moratom koji pruža fizičku prisutnost u šesnaestercu i Ferran Torresom čija brzina i dribling otvaraju prostor. Mladi talenti poput Ansu Fatija i Pedra Gonzáleza Pedrija donose svježinu i nepredvidivost, što bi moglo biti ključno u trenucima kada utakmice treba prelomiti.', '6.jpeg', 'sport', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `vijesti`
--
ALTER TABLE `vijesti`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vijesti`
--
ALTER TABLE `vijesti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
